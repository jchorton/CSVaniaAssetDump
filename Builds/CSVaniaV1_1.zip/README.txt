***********
* CSVania *
***********
Oregon State University 
CS467 Team Cepheus, Fall 2017

This game was produced a capstone project for our Computer Science BS degrees. It is meant as a demonstration of our ability to a) program in an unfamiliar environment, b) work in a group using online planning and communication, and c) produce a functioning product. It is a short game, but please enjoy it!


Goal:
Escape from the dungeon! To do this, you must maneuver your character through the tunnels. Watch out! This dangerous dungeon is filled with monsters! You'll have to use your weapons and wits to gather the keys and pass through the gates to reach freedom!


Starting the Game:
The folder this README was in should also contain an executable file. Opening that should bring up a launcher to configure display and control settings. (16:9 aspect ratio is required.) The launcher will then load the title screen for the game!


Controls:
Controls are configurable in the game's launcher. By default, the WASD keys and spacebar are used for manuevering the player. The mouse buttons are used for attacks.

W = climb up (climbing)
A = move left
S = defend, climb down (climbing)
D = move right

Spacebar = jump, hold button to jump higher

LMB = swing sword
RMB = throw dagger

Escape = pause and display options


Contact:
- Jonathan Horton  
https://www.linkedin.com/in/hortonjc/

- Spencer Moran    
https://www.linkedin.com/in/spencer-m-393b5412/

- Justin Senato
https://www.linkedin.com/in/justin-senato-3ab78166/


Demo Video:
https://youtu.be/5IsP7MNEriI

